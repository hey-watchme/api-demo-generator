#!/usr/bin/env python3
"""
Demo Data Generator Lambda Function
モックユーザーのdashboard_summaryデータを定期的に生成してSupabaseに挿入
EventBridge (Cron)により30分ごとに実行される
"""

import os
import json
from datetime import datetime, timezone, timedelta
from supabase import create_client, Client

# 環境変数
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")

# モックデバイスID（デモ専用UUID）
MOCK_DEVICE_ID = "a1b2c3d4-e5f6-4a5b-8c9d-0e1f2a3b4c5d"

# 静的テンプレートデータ（CSVから抽出）
TEMPLATE_DATA = {
    "prompt": """## 1日全体の総合分析依頼

### 分析対象
観測対象者: 5歳の男性（白幡幼稚園　年長さん
趣味はマイクラ）
日付: 2025-10-02（木曜日、平日）
季節: 秋、地域: 日本
分析範囲: **1日全体（00:00〜23:30）の記録**



録音される音声には本人だけでなく、周囲の人物（家族、友人、テレビ等）の声も含まれます。
観測対象者のプロファイルと発話内容に乖離がある場合は、周囲の人物の発話である可能性を考慮してください。
（例：年齢や発達段階に不相応な専門的内容は周囲の大人の会話、観測対象者の属性と異なる声質は他者の発話など）

### 1日の活動記録（48ブロック記録）
[06:00]    0 | 平日の朝6時ごろで、まだ眠っている可能性が最も高い。発話がないことは、眠っている状態が自然な解釈を支持する情報である。
[18:00]  -25 | 平日の木曜日18時の放課後、家で過ごしており動画視聴が主な活動である可能性が最も高い。発話内容『ずっと動画ばっかの時』からも動画視聴への強い言及があり、この活動がこの時間帯に集中していると推測される。
[19:00]  +40 | 7時頃の家庭のキッチンで夕食の準備をしている、あるいは家族と一緒に餃子づくりを楽しんでいる場面が最も自然です。発話には料理の計画や手順を示す内容が混ざっており、板の上に物を乗せてどこかに置く動作の描写があることから、手伝いをしている状況と考えられます。

### 検出された感情の変化点（参考情報）
- 07:00: スコアが0から30へ変化（変化量: +30）
  状況: 平日朝の時間帯で、5歳児は学校へ向けた朝の準備をしている可能性が最も高い。発話がない点から、今は会話
- 09:30: スコアが10から40へ変化（変化量: +30）
  状況: 09:30の平日、5歳の男児は幼稚園・保育園で静かな活動に参加していると考えられる。発話がない点から
- 10:30: スコアが30から0へ変化（変化量: -30）
  状況: 平日の午前10時半は、5歳児にとって静かな休憩時間である可能性が最も高い。発話がない状態はこの時間帯
- 18:00: スコアが25から-25へ変化（変化量: -50）
  状況: 平日の木曜日18時の放課後、家で過ごしており動画視聴が主な活動である可能性が最も高い。発話内容『ずっ
- 18:30: スコアが-25から25へ変化（変化量: +50）
  状況: 平日の18:30は夕食・食事の時間帯として最も自然です。発話がない状態でも、家族と一緒に静かに食事を


### 重要：1日全体を総合的に評価してください
これは23:30時点での**1日全体のラップアップ**です。
朝から現在までの全タイムブロックのデータを俯瞰し、1日の流れと変化を総合的に評価してください。
特定の時間帯だけでなく、1日を通しての活動パターン、感情の推移、特徴的な出来事を含めてください。""",
    "processed_count": 48,
    "last_time_block": "23-30",
    "average_vibe": 8.85417,
    "insights": "朝から昼にかけて、眠さを含みつつ徐々に機嫌が高まり、起床・準備での前向きさが見られた。午前中の園での静かな活動を経て気分は安定域に達するも、10:30頃には一時的に落ち込み0へ戻る場面が発生した。午後には放課後の家庭環境で気分が低下する場面があり夕方には回復の兆しが見え始め、18:30には家族と夕食前後の時間で再び前向きさを取り戻している。インサイト：日中は活動の変化に敏感で、特に夕方の家族との時間帯に感情が安定しやすい傾向が見られ、環境要因が強く影響している可能性が高い。",
    "analysis_result": {
        "raw_response": '{\n  "current_time": "23:30",\n  "time_context": "深夜",\n  "cumulative_evaluation": "朝は眠っている可能性が高く、7時台の準備で気分が上向き、9:30頃には幼稚園で静かな活動に集中する安定感が見られた。午前の後半には休憩を挟みつつも午後にかけて感情が揺れ、放課後には動画視聴中心の活動が主となって気分が落ち込む場面がありつつ、18:30以降の夕食・家族との時間で回復の兆しが見え、19時の家庭作業で前向きな気分が継続した。インサイトとしては、日中は規則的なルーティンと家庭の支えが感情の安定に寄与する一方、長時間の画面視聴が短期的な落ち込みを招く傾向があり、Minecraftを含む趣味的活動が安定感の支えになっている可能性がある。",\n  "mood_trajectory": "fluctuating",\n  "current_state_score": 16,\n  "burst_events": [\n    {\n      "time": "07:00",\n      "event": "朝の準備で活動が活発になり気分が上向き",\n      "score_change": 30,\n      "from_score": 0,\n      "to_score": 30\n    },\n    {\n      "time": "09:30",\n      "event": "幼稚園で静かな活動に集中し安定感が増す",\n      "score_change": 30,\n      "from_score": 10,\n      "to_score": 40\n    },\n    {\n      "time": "10:30",\n      "event": "午前の休憩で気分が落ち着かなくなる",\n      "score_change": -30,\n      "from_score": 40,\n      "to_score": 0\n    },\n    {\n      "time": "18:00",\n      "event": "放課後、家で動画視聴が主活動となり気分が落ち込む",\n      "score_change": -50,\n      "from_score": 25,\n      "to_score": -25\n    },\n    {\n      "time": "18:30",\n      "event": "夕食・家族と過ごす時間で急激に気分が回復",\n      "score_change": +50,\n      "from_score": -25,\n      "to_score": 25\n    }\n  ]\n}',
        "processing_error": "JSON解析エラー: Expecting value: line 39 column 23 (char 1116)",
        "extracted_content": '{\n  "current_time": "23:30",\n  "time_context": "深夜",\n  "cumulative_evaluation": "朝は眠っている可能性が高く、7時台の準備で気分が上向き、9:30頃には幼稚園で静かな活動に集中する安定感が見られた。午前の後半には休憩を挟みつつも午後にかけて感情が揺れ、放課後には動画視聴中心の活動が主となって気分が落ち込む場面がありつつ、18:30以降の夕食・家族との時間で回復の兆しが見え、19時の家庭作業で前向きな気分が継続した。インサイトとしては、日中は規則的なルーティンと家庭の支えが感情の安定に寄与する一方、長時間の画面視聴が短期的な落ち込みを招く傾向があり、Minecraftを含む趣味的活動が安定感の支えになっている可能性がある。",\n  "mood_trajectory": "fluctuating",\n  "current_state_score": 16,\n  "burst_events": [\n    {\n      "time": "07:00",\n      "event": "朝の準備で活動が活発になり...'
    },
    "vibe_scores": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 30, 30, 30, 10, 40, 30, 0, 0, 25, 10, 0, 0, 0, 0, 0, 0, 0, 25, 40, 30, 25, -25, 25, 40, 20, 25, 0, -15, 0, 0, 0, 0, 0],
    "burst_events": [
        {"time": "07:00", "event": "朝の起床・準備で機嫌が上昇した", "to_score": 30, "from_score": 0, "score_change": 30},
        {"time": "09:30", "event": "園で静かな活動を通じて気分が上昇し40に到達", "to_score": 40, "from_score": 30, "score_change": 10},
        {"time": "10:30", "event": "午前中の休憩で急に気分が低下して0へ", "to_score": 0, "from_score": 40, "score_change": -40},
        {"time": "18:00", "event": "放課後、家で動画視聴などで一時的に気分が低下", "to_score": -25, "from_score": 0, "score_change": -25},
        {"time": "18:30", "event": "家族と夕食前後の時間で回復し、前向きさが戻る", "to_score": 25, "from_score": -25, "score_change": 50}
    ]
}


def get_jst_time():
    """JSTタイムゾーンで現在時刻を取得"""
    jst = timezone(timedelta(hours=9))
    return datetime.now(jst)


def generate_mock_dashboard_data():
    """モックdashboard_summaryデータを生成（静的テンプレートベース）"""
    jst_now = get_jst_time()
    today = jst_now.date()

    data = {
        "device_id": MOCK_DEVICE_ID,
        "date": str(today),
        "prompt": TEMPLATE_DATA["prompt"],
        "processed_count": TEMPLATE_DATA["processed_count"],
        "last_time_block": TEMPLATE_DATA["last_time_block"],
        "created_at": jst_now.isoformat(),
        "updated_at": jst_now.isoformat(),
        "average_vibe": TEMPLATE_DATA["average_vibe"],
        "insights": TEMPLATE_DATA["insights"],
        "analysis_result": TEMPLATE_DATA["analysis_result"],
        "vibe_scores": TEMPLATE_DATA["vibe_scores"],
        "burst_events": TEMPLATE_DATA["burst_events"]
    }

    return data


def lambda_handler(event, context):
    """
    Lambda関数のメインハンドラー
    EventBridgeから30分ごとに呼び出される
    """
    print(f"[{get_jst_time().isoformat()}] Demo data generator started")
    print(f"Event: {json.dumps(event)}")

    # Supabase接続確認
    if not SUPABASE_URL or not SUPABASE_KEY:
        error_msg = "Missing Supabase credentials in environment variables"
        print(f"ERROR: {error_msg}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": error_msg})
        }

    try:
        # Supabaseクライアント作成
        supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

        # モックデータ生成
        mock_data = generate_mock_dashboard_data()
        print(f"Generated mock data for device: {MOCK_DEVICE_ID}")
        print(f"Date: {mock_data['date']}")

        # データ挿入（upsert: device_id + date が重複する場合は更新）
        result = supabase.table("dashboard_summary").upsert(mock_data).execute()

        print(f"Successfully upserted data to dashboard_summary")
        print(f"Result count: {len(result.data)}")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Demo data generated successfully",
                "device_id": MOCK_DEVICE_ID,
                "date": mock_data["date"],
                "timestamp": get_jst_time().isoformat()
            }, default=str, ensure_ascii=False)
        }

    except Exception as e:
        import traceback
        error_msg = f"Error generating demo data: {str(e)}"
        print(f"ERROR: {error_msg}")
        print(f"Traceback: {traceback.format_exc()}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": error_msg,
                "traceback": traceback.format_exc()
            })
        }
