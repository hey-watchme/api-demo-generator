"""
HTTP/2 protocol implementation for Python.
"""
from __future__ import annotations

__version__ = "4.3.0"
